using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{
    public bool canMove = true;
    private Rigidbody2D myBody; 

    [SerializeField]
    float maxPos;
    [SerializeField]
    float moveSpeed;
    float xBound; 

    void Start()
    {
        myBody = GetComponent<Rigidbody2D>(); 
    }

    void Update()
    {
        if (canMove)
        {
            Move(); 
        }
        
    }

    private void Move()
    {
        //Movement left & right 
        float inputX = Input.GetAxis("Horizontal");
        if (inputX > 0)
            myBody.velocity = Vector2.right * moveSpeed;
        else if (inputX < 0)
            myBody.velocity = Vector2.left * moveSpeed;
        else
            myBody.velocity = Vector2.zero;

    }
}
