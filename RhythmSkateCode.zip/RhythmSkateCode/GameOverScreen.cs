using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GameOverScreen : MonoBehaviour
{
    public Text pointsText;
    //gameObject.SetActive(false);
    public void Setup()
    {
        gameObject.SetActive(true);
        //pointsText.text = score1.ToString() + "POINTS"; 
    }
}
