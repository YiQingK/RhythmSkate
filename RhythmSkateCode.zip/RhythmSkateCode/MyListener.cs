/**
 * Ardity (Serial Communication for Arduino + Unity)
 * Author: Daniel Wilches <dwilches@gmail.com>
 * Modifications for InterfaceLab 2020 to move a cube
 *
 * This work is released under the Creative Commons Attributions license.
 * https://creativecommons.org/licenses/by/2.0/
 */
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class MyListener : MonoBehaviour
{
    bool canmove = true;
    Vector3 movec = Vector3.zero;
    //Line: 0 - Left, 1 - Center, 2 - Right
    int line = 1;
    int targetline = 1;
    public int laneDistance;
    int trigger = 0;

    public Text scoreText;
    //if the game permits we can also do an accuracy thing too w/ Ranking systems like they do in DDR 
    public int score = 0;
    public int beatsCollected = 0;

    void Start() // Start is called before the first frame update
    {
    }
    void Update() // Update is called once per frame
    {
        Move();
        this.transform.Translate(movec * Time.deltaTime * 50);
        scoreText.text = "Score: " + score.ToString();
    }

    void checkArduinoInput(int gyro)
    {
        //Left
        if (gyro == 0 && canmove && line > 0)
        {
            targetline--;
            canmove = false;
            movec.x = -4;
        }
        //Right
        if (gyro == 1 && canmove && line < 2)
        {
            targetline++;
            canmove = false;
            movec.x = 4;
        }
    }

    void OnMessageArrived(string msg)
    {
        //Debug.Log(msg);
        string[] msgsplit = msg.Split(',');

        int inputType = int.Parse(msgsplit[0]);

        int input = int.Parse(msgsplit[1]);
        if(inputType == 0)
        {
            if(input == 1)
            {
                trigger = 1;
            }
        }
        else if (inputType == 1)
        {
            Move();
            checkArduinoInput(input);
            this.transform.Translate(movec * Time.deltaTime * 50);
        }

    }

    void Move()
    {
        Vector3 pos = transform.position;
        //Checks current line is not target line
        if (!line.Equals(targetline))
        {
            //Checks if target line is 0
            if (targetline == 0 && pos.x < -laneDistance)
            {
                transform.position = new Vector3(-laneDistance, pos.y, pos.z);
                line = targetline;
                canmove = true;
                movec.x = 0;
            }
            //Checks if target line is 1
            else if (targetline == 1 && (pos.x > 0 || pos.x < 0))
            {
                //Checks if it is currently on 0 
                if (line == 0 && pos.x > 0)
                {
                    transform.position = new Vector3(0, pos.y, pos.z);
                    line = targetline;
                    canmove = true;
                    movec.x = 0;
                }
                //Checks if it is currently on 2
                else if (line == 2 && pos.x < 0)
                {
                    transform.position = new Vector3(0, pos.y, pos.z);
                    line = targetline;
                    canmove = true;
                    movec.x = 0;
                }
            }
            //Check if target line is 2
            else if (targetline == 2 && pos.x > laneDistance)
            {
                transform.position = new Vector3(laneDistance, pos.y, pos.z);
                line = targetline;
                canmove = true;
                movec.x = 0;
            }
        }
    }

    // Invoked when a connect/disconnect event occurs. The parameter 'success'
    // will be 'true' upon connection, and 'false' upon disconnection or
    // failure to connect.
    void OnConnectionEvent(bool success)
    {
        Debug.Log(success ? "Device connected" : "Device disconnected");
    }

    void OnTriggerEnter2D(Collider2D collision)
    {

        if (collision.tag == "Beats" && trigger == 1)
        {
            Debug.Log(trigger);
            Destroy(collision.gameObject);
            score = score + 5;
            beatsCollected++;
            trigger = 0;
            Debug.Log(trigger);
        }
    }
}