using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class PlatformBehavior : MonoBehaviour
{
    public int scoreMissed = 0;
    public GameObject missEffect;

    //PlatformBehavior.scoreMissed 

    void Start()
    {
        
    }

    void Update()
    {
        
    }
    void OnTriggerEnter2D(Collider2D collision)
    {
        //just so all the beats falling screen will be destroyed and not fall into the void forever
        //ofc we can just kill the beats if they hit a certain y value but idk that value yet when we merging projects 

        //Instanstiate a miss! 
        if (collision.tag == "Beats")
        {
            GameObject missed = Instantiate(missEffect); //, collision.gameObject.position, Quaternion.identity
            Destroy(collision.gameObject);
            
            scoreMissed++; //Calculate accuracy if we wanted to 
            Destroy(missed, 0.5f);
        }
    }

    
}
