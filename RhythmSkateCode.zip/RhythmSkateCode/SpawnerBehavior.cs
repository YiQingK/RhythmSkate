using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class SpawnerBehavior : MonoBehaviour
{
    public GameObject[] beats;
    public GameObject obstacle;
    

    float[] xValues = { -2.1f, 0.01f, 2.1f }; //replace these values 

    public float yBound, picked;
    public float xBounds1, xBounds2, xBounds3;

    public bool gameOverBool = false;
    public int numBeats;
    [SerializeField]
    public int finalNumBeats;
    [SerializeField] GameObject GameOverPrefab, textPrefab;
    public Text pointsText;


    // Start is called before the first frame update
    void Start()
    {
        StartCoroutine(SpawnRandomGameObject());
        gameOverBool = false;
    }

    // Update is called once per frame
    void Update()
    {
        int randomIndex = Random.Range(0, xValues.Length);
        float randomXValue = xValues[randomIndex];
        picked = xValues[randomIndex];

        if (numBeats > finalNumBeats)
        {
            gameOverBool = true;
            Instantiate(GameOverPrefab);
            numBeats = 0;
            finalNumBeats = 0; //setting it equal to each other so it cancels out the if statement and not spawns so many GOPrefabs

            //pointsText.text = score.ToString() + " POINTS";
        }

    }

    IEnumerator SpawnRandomGameObject()
    {
        yield return new WaitForSeconds(Random.Range(1, 2)); //need to replace this so it follows the beat of the song 

        int randomBeat = Random.Range(0, beats.Length);

        if (Random.value <= 0.6f && gameOverBool == false)
        {
            Instantiate(beats[randomBeat], new Vector2(picked, yBound), Quaternion.identity);
            numBeats++;
        }
            


        //Instantiate(beats[randomBeat], new Vector2(Random.Range(xBounds, xBounds1), yBound), Quaternion.identity);
        //else // if we add obstacles lol 
        // Instantiate(obstacle, new Vector2(Random.Range(-xBounds, xBounds), yBound), Quaternion.identity);

        StartCoroutine(SpawnRandomGameObject());
    }

    
}
