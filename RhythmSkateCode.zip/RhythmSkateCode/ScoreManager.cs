using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class ScoreManager : MonoBehaviour
{
    //public static ScoreManager instance;

    public Text scoreText;
    //if the game permits we can also do an accuracy thing too w/ Ranking systems like they do in DDR 
    public int score = 0;
    public int beatsCollected = 0;

    public GameOverScreen GameOverScreen;

    public PlatformBehavior script; 


    void Start()
    {
        //script = GameObject.GetComponent<PlatformBehavior>();
    }

    void Update()
    {
        scoreText.text = "Score: " + score.ToString();

        /*if ((beatsCollected + GameObject.Find("Scoring Platform").GetComponent<PlatformBehavior>().scoreMissed) > 15) {
            gameOverbool = true;     
            GameOverScreen.Setup(); 
        }*/


    }


}
